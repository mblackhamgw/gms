=Ver: 2.0
##----------------------------------------
=Pkg: python-pyasn1-modules 0.0.5 4.7 noarch
=Sum: Collection of protocols modules written in ASN.1 language
+Des:
This is an implementation of ASN.1 types and codecs in Python programming
language. It has been first written to support particular protocol (SNMP) but
then generalized to be suitable for a wide range of protocols based on ASN.1
specification.
-Des:
##----------------------------------------
=Pkg: ImageMagick 6.8.8.1 71.33.1 x86_64
=Sum: Viewer and Converter for Images
+Des:
ImageMagick is a robust collection of tools and libraries to read,
write, and manipulate an image in many image formats, including popular
formats like TIFF, JPEG, PNG, PDF, PhotoCD, and GIF. With ImageMagick,
you can create images dynamically, making it suitable for Web
applications. You can also resize, rotate, sharpen, color-reduce, or
add special effects to an image and save your completed work in many
different image formats. Image processing operations are available from
the command line as well as through C, C++, and PERL-based programming
interfaces.
-Des:
##----------------------------------------
=Pkg: datasync-common 18.1.0.7586 1.1 x86_64
=Sum: DataSync common shared files
+Des:
datasync-common provides the base components for Micro Focus GroupWise Mobility Service.
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-PySQLPool 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: PySQLPool
+Des:
DataSync Shared Library: PySQLPool
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-cherrypy 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: cherrypy
+Des:
DataSync Shared Library: cherrypy
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-django 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: django
+Des:
DataSync Shared Library: django
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-iso8601 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: iso8601
+Des:
DataSync Shared Library: iso8601
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-networkx 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: networkx
+Des:
DataSync Shared Library: networkx
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-ntlm 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: ntlm
+Des:
DataSync Shared Library: ntlm
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-pytz 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: pytz
+Des:
DataSync Shared Library: pytz
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-requests 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: requests
+Des:
DataSync Shared Library: requests
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-soaplib 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: soaplib
+Des:
DataSync Shared Library: soaplib
-Des:
##----------------------------------------
=Pkg: datasync-common-lib-suds 18.1.0.7586 1.1 x86_64
=Sum: DataSync Shared Library: suds
+Des:
DataSync Shared Library: suds
-Des:
##----------------------------------------
=Pkg: datasync-configengine 18.1.0.7586 1.1 x86_64
=Sum: DataSync Configuration and Management Engine
+Des:
ConfigEngine configures and manages Datasync properties
-Des:
##----------------------------------------
=Pkg: datasync-syncengine 18.1.0.7586 1.1 x86_64
=Sum: DataSync Core Syncronization Engine
+Des:
Provides synchronization capabilities for Datasync
-Des:
##----------------------------------------
=Pkg: datasync-syncengine-connector-engine 18.1.0.7586 1.1 x86_64
=Sum: Connector component for the Data Synchronizer project
+Des:
Engine Connector component for Novell Data Synchronizer.
-Des:
##----------------------------------------
=Pkg: datasync-syncengine-connector-groupwise 18.1.0.7586 1.1 x86_64
=Sum: Connector component for the Data Synchronizer project
+Des:
GroupWise Connector component for Novell Data Synchronizer.
-Des:
##----------------------------------------
=Pkg: datasync-syncengine-connector-mobility 18.1.0.7586 1.1 x86_64
=Sum: Connector component for the Data Synchronizer project
+Des:
Mobility Connector component for Novell Data Synchronizer.
-Des:
##----------------------------------------
=Pkg: datasync-webadmin 18.1.0.7586 1.1 x86_64
=Sum: DataSync Web Administration Tools
+Des:
DataSync synchronizes.
-Des:
##----------------------------------------
=Pkg: datasynchronizer-mobilitypack-release 18.1.0 1.2 x86_64
=Sum: GroupWise Mobility Service
+Des:
Micro Focus GroupWise Mobility Service allows customers to synchronize their GroupWise data to compatible mobile platforms such as tablets and phones.
-Des:
##----------------------------------------
=Pkg: datasynchronizer-mobilitypack-release-cd 18.1.0 1.2 x86_64
=Sum: GroupWise Mobility Service
+Des:
Micro Focus GroupWise Mobility Service allows customers to synchronize their GroupWise data to compatible mobile platforms such as tablets and phones.
-Des:
##----------------------------------------
=Pkg: libMagickCore-6_Q16-1 6.8.8.1 71.33.1 x86_64
=Sum: Viewer and Converter for Images - runtime library
+Des:
ImageMagick is a robust collection of tools and libraries to read,
write, and manipulate an image in many image formats, including popular
formats like TIFF, JPEG, PNG, PDF, PhotoCD, and GIF. With ImageMagick,
you can create images dynamically, making it suitable for Web
applications. You can also resize, rotate, sharpen, color-reduce, or
add special effects to an image and save your completed work in many
different image formats. Image processing operations are available from
the command line as well as through C, C++, and PERL-based programming
interfaces.
-Des:
##----------------------------------------
=Pkg: libMagickWand-6_Q16-1 6.8.8.1 71.33.1 x86_64
=Sum: Viewer and Converter for Images - runtime library
+Des:
ImageMagick is a robust collection of tools and libraries to read,
write, and manipulate an image in many image formats, including popular
formats like TIFF, JPEG, PNG, PDF, PhotoCD, and GIF. With ImageMagick,
you can create images dynamically, making it suitable for Web
applications. You can also resize, rotate, sharpen, color-reduce, or
add special effects to an image and save your completed work in many
different image formats. Image processing operations are available from
the command line as well as through C, C++, and PERL-based programming
interfaces.
-Des:
##----------------------------------------
=Pkg: librtfcomp0 1.1 2.18 x86_64
=Sum: LZRTF compression library
+Des:
LZRTF compression library. It is used in the SynCE project.
-Des:
##----------------------------------------
=Pkg: psqlODBC 09.03.0300 4.1 x86_64
=Sum: ODBC Driver for PostgreSQL
+Des:
This package contains the ODBC (Open DataBase Connectivity) driver and
sample configuration files needed for applications to access a
PostgreSQL database using ODBC.
-Des:
##----------------------------------------
=Pkg: python-M2Crypto 0.21.1 16.59 x86_64
=Sum: Crypto and SSL toolkit for Python
+Des:
M2Crypto is a crypto and SSL toolkit for Python featuring the
following:

RSA, DSA, DH, HMACs, message digests, symmetric ciphers (including
AES). SSL functionality to implement clients and servers. HTTPS
extensions to Python's httplib, urllib, and xmlrpclib. Unforgeable
HMAC'ing AuthCookies for web session management. FTP/TLS client and
server. S/MIME. ZServerSSL: A HTTPS server for Zope. ZSmime: An S/MIME
messenger for Zope.

It currently lives at
http://wiki.osafoundation.org/bin/view/Projects/MeTooCrypto. The
original M2Crypto homepage is at http://sandbox.rulemaker.net/ngps/m2/.
-Des:
##----------------------------------------
=Pkg: python-ldap 2.4.15 1.9 x86_64
=Sum: Python LDAP interface
+Des:
python-ldap provides an LDAP client API for Python in the spirit of
RFC1823. It includes a Python module called _ldapmodule that wraps an
LDAP C library, an object-oriented API for X.500 directories. See
python-ldap pages on http://python-ldap.sourceforge.net/
-Des:
##----------------------------------------
=Pkg: python-lxml 2.2.2 3.18 x86_64
=Sum: A Pythonic Binding for the libxml2 and libxslt Libraries
+Des:
lxml is a Pythonic binding for the libxml2 and libxslt libraries. It
follows the ElementTree API as much as possible, building it on top of
the native libxml2 tree. It also extends this API to expose libxml2 and
libxslt specific functionality, such as XPath, Relax NG, XML Schema,
XSLT, and c14n.
-Des:
##----------------------------------------
=Pkg: python-psycopg2 2.4.2 2.23 x86_64
=Sum: Python-PostgreSQL Database Adapter
+Des:
psycopg2 is a PostgreSQL database adapter for the Python programming
language.  psycopg2 was written with the aim of being very small and fast,
and stable as a rock.

psycopg2 is different from the other database adapter because it was
designed for heavily multi-threaded applications that create and destroy
lots of cursors and make a conspicuous number of concurrent INSERTs or
UPDATEs. psycopg2 also provide full asycronous operations and support
for coroutine libraries.
-Des:
##----------------------------------------
=Pkg: python-pyodbc 2.1.6 1.26 x86_64
=Sum: pyodbc is a Python module that allows you to use ODBC to connect to almost any database.
+Des:
pyodbc is a Python module that allows you to use ODBC to connect to almost any database.
-Des:
##----------------------------------------
=Pkg: python-rtfcomp 1.1 2.18 x86_64
=Sum: Python bindings for librtfcomp
+Des:
This package contains the python bindings for librtfcomp.
-Des:
